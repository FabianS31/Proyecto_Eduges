
from django.db import models
from django.utils import timezone


class EstadoPaciente(models.Model):
    id_estado_paciente = models.AutoField(
        primary_key=True,
        db_column='ID_EstadoPaciente'
    )

    estado = models.CharField(
        max_length=100,
        db_column='Estado'
    )

    class Meta:
        managed = False
        db_table = 'estados_pacientes'


class Paciente(models.Model):
    id_paciente = models.AutoField(
        primary_key=True,
        db_column='ID_Paciente'
    )

    nombre = models.CharField(
        max_length=100,
        db_column='Nombre'
    )

    apellido = models.CharField(
        max_length=100,
        db_column='Apellido'
    )

    dni = models.CharField(
        max_length=20,
        unique=True,
        db_column='DNI'
    )

    fecha_nacimiento = models.DateField(
        db_column='FechaNacimiento'
    )

    fecha_alta = models.DateField(
        db_column='FechaAlta',
        null=True,
        blank=True,
        default=timezone.localdate
    )

    direccion = models.CharField(
        max_length=255,
        db_column='Direccion'
    )

    mail = models.CharField(
        max_length=50,
        db_column='Mail',
        null=True,
        blank=True
    )

    consentimiento = models.BooleanField(
        db_column='Consentimiento'
    )

    cud_numero = models.CharField(
        max_length=20,
        db_column='CUD_Numero',
        null=True,
        blank=True
    )

    cud_vencimiento = models.DateField(
        db_column='CUD_Vencimiento',
        null=True,
        blank=True
    )

    obra_social = models.ForeignKey(
        'ObraSocial',
        on_delete=models.PROTECT,
        db_column='ID_ObraSocial'
    )

    numero_afiliado = models.CharField(
        max_length=20,
        db_column='NumeroAfiliado'
    )

    estado = models.ForeignKey(
        EstadoPaciente,
        on_delete=models.PROTECT,
        db_column='ID_EstadoPaciente'
    )

    class Meta:
        managed = False
        db_table = 'pacientes'